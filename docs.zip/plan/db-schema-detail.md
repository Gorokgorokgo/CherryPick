상세 스키마가 필요한 시점:

- 실제 데이터베이스 마이그레이션 스크립트 작성할 때
- 성능 최적화 (인덱스, 파티셔닝) 작업할 때
- 제약조건 추가할 때
- 초기 데이터 (템플릿, 지역 등) 삽입할 때

````
# CherryPick 데이터베이스 상세 스키마

## 📋 테이블 구조 및 설계 근거

### 👤 사용자 관련 테이블

#### `users` - 사용자 기본 정보
```sql
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    nickname VARCHAR(50),
    profile_image VARCHAR(500),
    buyer_level INTEGER DEFAULT 1,
    seller_level INTEGER DEFAULT 1,
    buyer_exp INTEGER DEFAULT 0,
    seller_exp INTEGER DEFAULT 0,
    trust_score DECIMAL(3,2) DEFAULT 0.00,
    region_code VARCHAR(10),
    region_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_users_phone ON users(phone_number);
CREATE INDEX idx_users_region ON users(region_code);
````

**설계 근거:**

- `phone_number`를 UK로 설정하여 중복 가입 방지
- 구매/판매 레벨과 경험치를 분리하여 각각의 활동에 대한 성취감 제공
- `trust_score`로 사용자 신뢰도 관리

#### `user_accounts` - 사용자 계좌 정보

```sql
CREATE TABLE user_accounts (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    bank_code VARCHAR(10) NOT NULL,
    bank_name VARCHAR(50) NOT NULL,
    account_number VARCHAR(500) NOT NULL, -- 암호화 저장
    account_holder VARCHAR(100) NOT NULL,
    is_verified BOOLEAN DEFAULT FALSE,
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_accounts_user ON user_accounts(user_id);
CREATE UNIQUE INDEX idx_accounts_primary ON user_accounts(user_id) WHERE is_primary = TRUE;
```

**설계 근거:**

- 계좌번호는 암호화하여 저장 (개인정보 보호)
- `is_primary`로 기본 계좌 관리 (한 사용자당 하나만)

### 🏷️ 경매 관련 테이블

#### `auctions` - 경매 정보

```sql
CREATE TYPE auction_category AS ENUM ('ELECTRONICS', 'FASHION', 'HOME', 'BOOKS', 'SPORTS', 'ETC');
CREATE TYPE auction_status AS ENUM ('SCHEDULED', 'ACTIVE', 'ENDED', 'COMPLETED', 'CANCELLED');
CREATE TYPE region_scope AS ENUM ('NEIGHBORHOOD', 'CITY', 'STATE', 'NATIONWIDE');

CREATE TABLE auctions (
    id BIGSERIAL PRIMARY KEY,
    seller_id BIGINT NOT NULL REFERENCES users(id),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category auction_category NOT NULL,
    start_price DECIMAL(12,2) NOT NULL,
    current_price DECIMAL(12,2) NOT NULL,
    hope_price DECIMAL(12,2) NOT NULL,
    deposit_amount DECIMAL(12,2) NOT NULL,
    auction_time_hours INTEGER NOT NULL,
    region_scope region_scope DEFAULT 'NEIGHBORHOOD',
    region_code VARCHAR(10),
    region_name VARCHAR(100),
    status auction_status DEFAULT 'SCHEDULED',
    view_count INTEGER DEFAULT 0,
    bid_count INTEGER DEFAULT 0,
    start_at TIMESTAMP NOT NULL,
    end_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_auctions_seller ON auctions(seller_id);
CREATE INDEX idx_auctions_status ON auctions(status);
CREATE INDEX idx_auctions_category ON auctions(category);
CREATE INDEX idx_auctions_end_time ON auctions(end_at);
CREATE INDEX idx_auctions_region ON auctions(region_code, region_scope);
```

**설계 근거:**

- `hope_price`를 별도로 저장하여 보증금 계산 (10%)
- `region_scope`로 지역 확장 단계 관리
- 경매 종료 처리를 위한 `end_at` 인덱스 최적화

#### `auction_images` - 경매 이미지

```sql
CREATE TABLE auction_images (
    id BIGSERIAL PRIMARY KEY,
    auction_id BIGINT NOT NULL REFERENCES auctions(id) ON DELETE CASCADE,
    image_url VARCHAR(500) NOT NULL,
    sort_order INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_auction_images_auction ON auction_images(auction_id, sort_order);
```

#### `auction_extensions` - 지역 확장 이력

```sql
CREATE TABLE auction_extensions (
    id BIGSERIAL PRIMARY KEY,
    auction_id BIGINT NOT NULL REFERENCES auctions(id),
    from_scope region_scope NOT NULL,
    to_scope region_scope NOT NULL,
    extended_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**설계 근거:**

- 지역 확장 이력을 추적하여 분석 데이터로 활용

### 💰 입찰 관련 테이블

#### `bids` - 입찰 정보

```sql
CREATE TYPE bid_status AS ENUM ('ACTIVE', 'OUTBID', 'WINNING', 'WON', 'LOST', 'CANCELLED');

CREATE TABLE bids (
    id BIGSERIAL PRIMARY KEY,
    auction_id BIGINT NOT NULL REFERENCES auctions(id),
    bidder_id BIGINT NOT NULL REFERENCES users(id),
    bid_amount DECIMAL(12,2) NOT NULL,
    is_auto_bid BOOLEAN DEFAULT FALSE,
    max_auto_bid_amount DECIMAL(12,2),
    status bid_status DEFAULT 'ACTIVE',
    bid_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_bids_auction ON bids(auction_id, bid_amount DESC);
CREATE INDEX idx_bids_bidder ON bids(bidder_id);
CREATE INDEX idx_bids_time ON bids(bid_time);
```

**설계 근거:**

- `bid_amount DESC` 인덱스로 최고가 조회 최적화
- 자동 입찰 기능을 위한 `max_auto_bid_amount` 필드

### 💳 포인트 관련 테이블

#### `points` - 포인트 거래 내역

```sql
CREATE TYPE point_type AS ENUM ('CHARGE', 'USE', 'REFUND', 'COMMISSION', 'REWARD', 'PENALTY');
CREATE TYPE point_status AS ENUM ('PENDING', 'COMPLETED', 'FAILED', 'CANCELLED');

CREATE TABLE points (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    type point_type NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    balance_after DECIMAL(12,2) NOT NULL,
    related_type VARCHAR(50), -- 'auction', 'bid', 'transaction'
    related_id BIGINT,
    description TEXT,
    status point_status DEFAULT 'COMPLETED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_points_user ON points(user_id, created_at DESC);
CREATE INDEX idx_points_related ON points(related_type, related_id);
```

#### `point_locks` - 포인트 잠금 관리

```sql
CREATE TYPE lock_status AS ENUM ('LOCKED', 'UNLOCKED', 'USED');

CREATE TABLE point_locks (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    auction_id BIGINT NOT NULL REFERENCES auctions(id),
    bid_id BIGINT NOT NULL REFERENCES bids(id),
    locked_amount DECIMAL(12,2) NOT NULL,
    status lock_status DEFAULT 'LOCKED',
    locked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    unlocked_at TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_point_locks_user ON point_locks(user_id, status);
CREATE INDEX idx_point_locks_auction ON point_locks(auction_id);
```

**설계 근거:**

- 입찰시 포인트 예치(lock) 시스템으로 안전한 거래 보장
- `balance_after`로 잔액 추적 및 정합성 검증

### 🔄 거래 관련 테이블

#### `transactions` - 거래 정보

```sql
CREATE TYPE transaction_status AS ENUM ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'DISPUTED');

CREATE TABLE transactions (
    id BIGSERIAL PRIMARY KEY,
    auction_id BIGINT NOT NULL REFERENCES auctions(id),
    seller_id BIGINT NOT NULL REFERENCES users(id),
    buyer_id BIGINT NOT NULL REFERENCES users(id),
    final_price DECIMAL(12,2) NOT NULL,
    commission_fee DECIMAL(12,2) NOT NULL,
    seller_amount DECIMAL(12,2) NOT NULL,
    status transaction_status DEFAULT 'PENDING',
    seller_confirmed BOOLEAN DEFAULT FALSE,
    buyer_confirmed BOOLEAN DEFAULT FALSE,
    seller_confirmed_at TIMESTAMP,
    buyer_confirmed_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_transactions_seller ON transactions(seller_id);
CREATE INDEX idx_transactions_buyer ON transactions(buyer_id);
CREATE INDEX idx_transactions_status ON transactions(status);
```

**설계 근거:**

- 양측 확인 시스템으로 안전한 거래 완료 처리
- 수수료와 실제 지급액을 미리 계산하여 저장

### 💬 채팅 관련 테이블

#### `chat_rooms` - 채팅방

```sql
CREATE TABLE chat_rooms (
    id BIGSERIAL PRIMARY KEY,
    auction_id BIGINT NOT NULL REFERENCES auctions(id),
    seller_id BIGINT NOT NULL REFERENCES users(id),
    buyer_id BIGINT NOT NULL REFERENCES users(id),
    last_message_at TIMESTAMP,
    seller_active BOOLEAN DEFAULT TRUE,
    buyer_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE UNIQUE INDEX idx_chat_rooms_auction_buyer ON chat_rooms(auction_id, buyer_id);
CREATE INDEX idx_chat_rooms_seller ON chat_rooms(seller_id);
CREATE INDEX idx_chat_rooms_buyer ON chat_rooms(buyer_id);
```

#### `chat_messages` - 채팅 메시지

```sql
CREATE TYPE message_type AS ENUM ('TEXT', 'IMAGE', 'SYSTEM', 'LOCATION');

CREATE TABLE chat_messages (
    id BIGSERIAL PRIMARY KEY,
    chat_room_id BIGINT NOT NULL REFERENCES chat_rooms(id),
    sender_id BIGINT NOT NULL REFERENCES users(id),
    message_content TEXT NOT NULL,
    message_type message_type DEFAULT 'TEXT',
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_chat_messages_room ON chat_messages(chat_room_id, created_at DESC);
CREATE INDEX idx_chat_messages_unread ON chat_messages(chat_room_id, is_read) WHERE is_read = FALSE;
```

### 🔔 알림 관련 테이블

#### `notifications` - 알림

```sql
CREATE TYPE notification_type AS ENUM ('BID', 'OUTBID', 'AUCTION_END', 'AUCTION_WON', 'TRANSACTION', 'CHAT', 'SYSTEM');

CREATE TABLE notifications (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    type notification_type NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT,
    data JSONB, -- 알림 관련 추가 데이터
    is_read BOOLEAN DEFAULT FALSE,
    is_pushed BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE INDEX idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX idx_notifications_unread ON notifications(user_id, is_read) WHERE is_read = FALSE;
```

### ⭐ 후기 및 신고 테이블

#### `reviews` - 거래 후기 (당근마켓 스타일)

```sql
CREATE TYPE reviewer_type AS ENUM ('SELLER', 'BUYER');
CREATE TYPE review_type AS ENUM ('POSITIVE', 'NEGATIVE');

CREATE TABLE reviews (
    id BIGSERIAL PRIMARY KEY,
    transaction_id BIGINT NOT NULL REFERENCES transactions(id),
    reviewer_id BIGINT NOT NULL REFERENCES users(id),
    reviewee_id BIGINT NOT NULL REFERENCES users(id),
    reviewer_type reviewer_type NOT NULL,
    review_type review_type NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스
CREATE UNIQUE INDEX idx_reviews_transaction_reviewer ON reviews(transaction_id, reviewer_type);
CREATE INDEX idx_reviews_reviewee ON reviews(reviewee_id, review_type);
CREATE INDEX idx_reviews_reviewer ON reviews(reviewer_id);
```

#### `review_templates` - 후기 템플릿

```sql
CREATE TYPE template_type AS ENUM ('SELLER_POSITIVE', 'SELLER_NEGATIVE', 'BUYER_POSITIVE', 'BUYER_NEGATIVE');

CREATE TABLE review_templates (
    id SERIAL PRIMARY KEY,
    template_type template_type NOT NULL,
    text VARCHAR(100) NOT NULL,
    emoji VARCHAR(10),
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);

-- 기본 템플릿 데이터
INSERT INTO review_templates (template_type, text, emoji, sort_order) VALUES
-- 판매자가 구매자에게 주는 긍정적 후기
('SELLER_POSITIVE', '좋은 가격에 거래해요', '💰', 1),
('SELLER_POSITIVE', '시간약속을 잘 지켜요', '⏰', 2),
('SELLER_POSITIVE', '친절하고 매너가 좋아요', '😊', 3),
('SELLER_POSITIVE', '응답이 빨라요', '⚡', 4),

-- 구매자가 판매자에게 주는 긍정적 후기
('BUYER_POSITIVE', '상품상태가 설명한 것과 같아요', '✅', 1),
('BUYER_POSITIVE', '좋은 상품을 저렴하게 판매해요', '👍', 2),
('BUYER_POSITIVE', '친절하고 상품설명을 자세히 해줘요', '📝', 3),
('BUYER_POSITIVE', '시간약속을 잘 지켜요', '⏰', 4),

-- 부정적 후기 (신중하게 사용)
('SELLER_NEGATIVE', '약속 시간에 나타나지 않았어요', '⛔', 1),
('BUYER_NEGATIVE', '상품상태가 설명과 달라요', '❌', 1);
```

### 🏷️ 시스템 테이블

#### `categories` - 카테고리

```sql
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id INTEGER REFERENCES categories(id),
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);
```

#### `regions` - 지역 정보

```sql
CREATE TABLE regions (
    code VARCHAR(10) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_code VARCHAR(10) REFERENCES regions(code),
    level INTEGER NOT NULL, -- 1: 시/도, 2: 시/군/구, 3: 읍/면/동
    sort_order INTEGER DEFAULT 0
);
```

## 🔗 주요 관계 및 제약조건

### 핵심 비즈니스 룰

1. **포인트 잠금**: 입찰시 해당 금액만큼 포인트 잠금
2. **경매 종료**: 스케줄러가 `end_at` 기준으로 자동 처리
3. **거래 완료**: 판매자와 구매자 모두 확인해야 완료
4. **보증금 관리**: `hope_price`의 10%를 경매 등록시 차감

### 성능 최적화

- **파티셔닝**: `points` 테이블을 월별로 파티셔닝 고려
- **인덱스**: 자주 조회되는 컬럼에 복합 인덱스 설정
- **캐싱**: 경매 상태, 현재가 등은 Redis에 캐싱

### 데이터 정합성

- **트랜잭션**: 포인트 관련 모든 작업은 DB 트랜잭션으로 처리
- **체크 제약**: 금액, 평점 등에 CHECK 제약조건 설정
- **외래키**: 참조 무결성을 위한 적절한 FK 설정

이 스키마는 CherryPick의 모든 비즈니스 요구사항을 충족하면서도 확장 가능한 구조로 설계되었습니다.

```

```
