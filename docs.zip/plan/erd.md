```
erDiagram
    %% 사용자 관련 테이블
    users {
        bigint id PK "사용자 ID"
        varchar phone_number UK "전화번호 (고유)"
        varchar nickname "닉네임"
        varchar profile_image "프로필 이미지 URL"
        integer buyer_level "구매자 레벨"
        integer seller_level "판매자 레벨"
        integer buyer_exp "구매자 경험치"
        integer seller_exp "판매자 경험치"
        decimal trust_score "신뢰도 점수"
        varchar region_code "지역 코드"
        varchar region_name "지역명"
        boolean is_active "활성 상태"
        timestamp created_at "생성일시"
        timestamp updated_at "수정일시"
    }

    user_accounts {
        bigint id PK "계좌 ID"
        bigint user_id FK "사용자 ID"
        varchar bank_code "은행 코드"
        varchar bank_name "은행명"
        varchar account_number "계좌번호 (암호화)"
        varchar account_holder "예금주"
        boolean is_verified "계좌 인증 여부"
        boolean is_primary "기본 계좌 여부"
        timestamp created_at "등록일시"
    }

    %% 경매 관련 테이블
    auctions {
        bigint id PK "경매 ID"
        bigint seller_id FK "판매자 ID"
        varchar title "제목"
        text description "상품 설명"
        enum category "카테고리"
        decimal start_price "시작가"
        decimal current_price "현재가"
        decimal hope_price "희망가"
        decimal deposit_amount "보증금"
        integer auction_time_hours "경매 시간(시간)"
        enum region_scope "지역 범위"
        varchar region_code "지역 코드"
        varchar region_name "지역명"
        enum status "경매 상태"
        integer view_count "조회수"
        integer bid_count "입찰 횟수"
        timestamp start_at "경매 시작 시간"
        timestamp end_at "경매 종료 시간"
        timestamp created_at "생성일시"
        timestamp updated_at "수정일시"
    }

    auction_images {
        bigint id PK "이미지 ID"
        bigint auction_id FK "경매 ID"
        varchar image_url "이미지 URL"
        integer sort_order "정렬 순서"
        timestamp created_at "업로드일시"
    }

    auction_extensions {
        bigint id PK "확장 ID"
        bigint auction_id FK "경매 ID"
        enum from_scope "기존 범위"
        enum to_scope "확장 범위"
        timestamp extended_at "확장일시"
    }

    %% 입찰 관련 테이블
    bids {
        bigint id PK "입찰 ID"
        bigint auction_id FK "경매 ID"
        bigint bidder_id FK "입찰자 ID"
        decimal bid_amount "입찰가"
        boolean is_auto_bid "자동 입찰 여부"
        decimal max_auto_bid_amount "최대 자동 입찰가"
        enum status "입찰 상태"
        timestamp bid_time "입찰 시간"
        timestamp created_at "생성일시"
    }

    %% 포인트 관련 테이블
    points {
        bigint id PK "포인트 거래 ID"
        bigint user_id FK "사용자 ID"
        enum type "거래 타입"
        decimal amount "거래 금액"
        decimal balance_after "거래 후 잔액"
        varchar related_type "연관 타입"
        bigint related_id "연관 ID"
        text description "거래 설명"
        enum status "거래 상태"
        timestamp created_at "거래일시"
    }

    point_locks {
        bigint id PK "포인트 잠금 ID"
        bigint user_id FK "사용자 ID"
        bigint auction_id FK "경매 ID"
        bigint bid_id FK "입찰 ID"
        decimal locked_amount "잠금 금액"
        enum status "잠금 상태"
        timestamp locked_at "잠금일시"
        timestamp unlocked_at "해제일시"
    }

    %% 거래 관련 테이블
    transactions {
        bigint id PK "거래 ID"
        bigint auction_id FK "경매 ID"
        bigint seller_id FK "판매자 ID"
        bigint buyer_id FK "구매자 ID"
        decimal final_price "최종 거래가"
        decimal commission_fee "수수료"
        decimal seller_amount "판매자 수령액"
        enum status "거래 상태"
        boolean seller_confirmed "판매자 확인"
        boolean buyer_confirmed "구매자 확인"
        timestamp seller_confirmed_at "판매자 확인일시"
        timestamp buyer_confirmed_at "구매자 확인일시"
        timestamp completed_at "거래 완료일시"
        timestamp created_at "거래 생성일시"
    }

    %% 채팅 관련 테이블
    chat_rooms {
        bigint id PK "채팅방 ID"
        bigint auction_id FK "경매 ID"
        bigint seller_id FK "판매자 ID"
        bigint buyer_id FK "구매자 ID"
        timestamp last_message_at "마지막 메시지 시간"
        boolean seller_active "판매자 활성 상태"
        boolean buyer_active "구매자 활성 상태"
        timestamp created_at "생성일시"
    }

    chat_messages {
        bigint id PK "메시지 ID"
        bigint chat_room_id FK "채팅방 ID"
        bigint sender_id FK "발신자 ID"
        text message_content "메시지 내용"
        enum message_type "메시지 타입"
        boolean is_read "읽음 여부"
        timestamp read_at "읽은 시간"
        timestamp created_at "전송일시"
    }

    %% 알림 관련 테이블
    notifications {
        bigint id PK "알림 ID"
        bigint user_id FK "사용자 ID"
        enum type "알림 타입"
        varchar title "알림 제목"
        text content "알림 내용"
        json data "추가 데이터"
        boolean is_read "읽음 여부"
        boolean is_pushed "푸시 발송 여부"
        timestamp read_at "읽은 시간"
        timestamp created_at "생성일시"
    }

    notification_settings {
        bigint id PK "설정 ID"
        bigint user_id FK "사용자 ID"
        boolean bid_notification "입찰 알림"
        boolean auction_end_notification "경매 종료 알림"
        boolean transaction_notification "거래 알림"
        boolean marketing_notification "마케팅 알림"
        timestamp updated_at "수정일시"
    }

    %% 후기 관련 테이블
    reviews {
        bigint id PK "후기 ID"
        bigint transaction_id FK "거래 ID"
        bigint reviewer_id FK "작성자 ID"
        bigint reviewee_id FK "대상자 ID"
        enum reviewer_type "작성자 타입"
        enum review_type "후기 타입"
        text content "후기 내용"
        timestamp created_at "작성일시"
    }

    review_templates {
        integer id PK "템플릿 ID"
        enum template_type "템플릿 타입"
        varchar text "후기 문구"
        varchar emoji "이모지"
        integer sort_order "정렬 순서"
        boolean is_active "활성 상태"
    }

    %% 신고 관련 테이블
    reports {
        bigint id PK "신고 ID"
        bigint reporter_id FK "신고자 ID"
        enum target_type "신고 대상 타입"
        bigint target_id "신고 대상 ID"
        enum reason "신고 사유"
        text description "신고 내용"
        enum status "처리 상태"
        timestamp processed_at "처리일시"
        timestamp created_at "신고일시"
    }

    %% 시스템 관련 테이블
    categories {
        integer id PK "카테고리 ID"
        varchar name "카테고리명"
        integer parent_id "상위 카테고리 ID"
        integer sort_order "정렬 순서"
        boolean is_active "활성 상태"
    }

    regions {
        varchar code PK "지역 코드"
        varchar name "지역명"
        varchar parent_code "상위 지역 코드"
        integer level "지역 단계"
        integer sort_order "정렬 순서"
    }

    %% 관계 정의
    users ||--o{ user_accounts : "계좌 소유"
    users ||--o{ auctions : "경매 등록"
    users ||--o{ bids : "입찰 참여"
    users ||--o{ points : "포인트 거래"
    users ||--o{ point_locks : "포인트 잠금"
    users ||--o{ notifications : "알림 수신"
    users ||--|| notification_settings : "알림 설정"
    users ||--o{ chat_messages : "메시지 발송"
    users ||--o{ reviews : "후기 작성(reviewer)"
    users ||--o{ reviews : "후기 받음(reviewee)"
    users ||--o{ reports : "신고 접수"

    auctions ||--o{ auction_images : "경매 이미지"
    auctions ||--o{ auction_extensions : "지역 확장"
    auctions ||--o{ bids : "입찰 받음"
    auctions ||--|| transactions : "거래 생성"
    auctions ||--|| chat_rooms : "채팅방 생성"

    bids ||--|| point_locks : "포인트 잠금"

    transactions ||--o{ reviews : "거래 후기"
    transactions ||--|| chat_rooms : "거래 채팅"

    chat_rooms ||--o{ chat_messages : "채팅 메시지"

    categories ||--o{ auctions : "카테고리 분류"
    regions ||--o{ users : "사용자 지역"
    regions ||--o{ auctions : "경매 지역"
```
