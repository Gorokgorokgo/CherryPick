# CherryPick 보안 가이드라인

CherryPick 프로젝트의 개발팀이 준수해야 할 보안 지침서입니다.

## 📋 목차

1. [예외 처리 보안 가이드](#예외-처리-보안-가이드)
2. [로깅 보안 정책](#로깅-보안-정책)
3. [데이터 보호 규칙](#데이터-보호-규칙)
4. [인증/인가 보안](#인증인가-보안)
5. [입력 검증 규칙](#입력-검증-규칙)
6. [보안 모니터링](#보안-모니터링)

## 🛡️ 예외 처리 보안 가이드

### 핵심 원칙

#### 1. 민감한 정보 노출 방지
```java
// ❌ 위험: 실제 잔액 정보 노출
throw new IllegalArgumentException("포인트 잔액이 부족합니다. 현재 잔액: " + balance + "원");

// ✅ 안전: 표준화된 메시지
throw new BusinessException(ErrorCode.INSUFFICIENT_POINTS);
```

#### 2. 시스템 내부 정보 숨김
```java
// ❌ 위험: 데이터베이스 구조 노출
throw new RuntimeException("users 테이블에서 user_id=123를 찾을 수 없습니다");

// ✅ 안전: 추상화된 메시지
throw EntityNotFoundException.user();
```

#### 3. 스택 트레이스 보호
```java
@ExceptionHandler(Exception.class)
public ResponseEntity<ErrorResponse> handleUnexpectedException(Exception e) {
    // ❌ 프로덕션에서 스택 트레이스 노출 금지
    log.error("Unexpected error: {}", e.getMessage(), e);
    
    // ✅ 사용자에게는 안전한 메시지만 반환
    return ResponseEntity.status(500)
        .body(ErrorResponse.of(ErrorCode.INTERNAL_SERVER_ERROR, request.getRequestURI()));
}
```

### ErrorCode 설계 규칙

#### 1. 표준화된 오류 코드 체계
```java
public enum ErrorCode {
    // 도메인별 코드 (첫 글자)
    INSUFFICIENT_POINTS("P001", "포인트가 부족합니다.", HttpStatus.BAD_REQUEST),
    SELF_BID_NOT_ALLOWED("B002", "자신의 경매에는 입찰할 수 없습니다.", HttpStatus.FORBIDDEN);
}
```

#### 2. 메시지 작성 가이드
- **DO**: 사용자 친화적, 액션 가능한 메시지
- **DON'T**: 기술적 세부사항, 시스템 내부 정보 포함

## 📊 로깅 보안 정책

### 로그 레벨별 보안 규칙

#### ERROR 레벨 - 보안 사고 추적
```java
// 보안 관련 실패 사례
log.error("Authentication failed for user request from IP: {}", request.getRemoteAddr());
log.error("Authorization denied for user {} accessing resource: {}", userId, resourcePath);
log.error("Multiple failed login attempts detected: IP={}, attempts={}", ipAddress, attemptCount);
```

#### WARN 레벨 - 보안 위험 감지
```java
// 의심스러운 활동 감지
log.warn("Suspicious activity detected: User {} attempted {} failed logins", userId, attemptCount);
log.warn("Rate limit exceeded for IP: {}, endpoint: {}", ipAddress, endpoint);
log.warn("Business exception occurred: {} at {}", errorCode, requestURI);
```

#### INFO 레벨 - 비즈니스 이벤트
```java
// 중요한 비즈니스 액션
log.info("User {} successfully placed bid on auction {}", userId, auctionId);
log.info("Auction {} ended with winner {}", auctionId, winnerId);
log.info("User {} completed profile update", userId);
```

#### DEBUG 레벨 - 개발용 (프로덕션 비활성화)
```java
// 개발 환경에서만 활성화
log.debug("Processing request: method={}, path={}", method, path);
log.debug("Query execution time: {}ms", executionTime);
```

### 민감 정보 로깅 금지 목록

#### 🚫 절대 로깅 금지
- 비밀번호 (평문/해시)
- JWT 토큰 전체
- 계좌번호 전체
- 주민등록번호
- 신용카드 정보
- 개인 연락처 정보

#### ⚠️ 마스킹 필요
```java
// 이메일 마스킹
String maskedEmail = email.replaceAll("(\\w{1,3})\\w*@", "$1***@");
log.info("User registered with email: {}", maskedEmail);

// 전화번호 마스킹
String maskedPhone = phone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1-****-$2");
log.info("Phone verification for: {}", maskedPhone);

// 계좌번호 마스킹 (마지막 4자리만)
String maskedAccount = "****-****-" + account.substring(account.length() - 4);
```

## 🔐 데이터 보호 규칙

### 1. 민감 데이터 분류

#### Level 1: 최고 기밀 (암호화 + 접근 제한)
- 비밀번호 해시
- 결제 정보
- 개인 식별 정보

#### Level 2: 제한 정보 (접근 제한)
- 포인트 잔액
- 입찰 내역
- 거래 기록

#### Level 3: 내부 정보 (인증된 사용자만)
- 경매 통계
- 사용자 활동 로그

### 2. 데이터 접근 원칙

#### 최소 권한 원칙
```java
// ✅ 자신의 데이터만 접근
public UserProfileResponse getUserProfile(Long userId) {
    User user = userRepository.findById(userId)
        .orElseThrow(EntityNotFoundException::user);
    return UserProfileResponse.from(user);
}

// ❌ 다른 사용자 데이터 접근 허용 금지
public UserProfileResponse getAnyUserProfile(Long targetUserId, Long requestUserId) {
    // 권한 검증 없이 접근 허용하면 안됨
}
```

#### 데이터 필터링
```java
// 응답 DTO에서 민감한 정보 제외
public class UserProfileResponse {
    private String email;        // ✅ 공개 가능
    private String nickname;     // ✅ 공개 가능
    // private Long pointBalance;   // ❌ 다른 사용자에게 노출 금지
    // private String phoneNumber;  // ❌ 개인정보 노출 금지
}
```

## 🔑 인증/인가 보안

### JWT 토큰 보안

#### 1. 토큰 생성 규칙
```java
// 최소한의 정보만 포함
private String generateToken(User user) {
    Map<String, Object> claims = new HashMap<>();
    claims.put("userId", user.getId());
    claims.put("role", user.getRole());
    // ❌ 민감한 정보 포함 금지: email, phone, balance 등
    
    return Jwts.builder()
        .setClaims(claims)
        .setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY))
        .signWith(key, SignatureAlgorithm.HS256)
        .compact();
}
```

#### 2. 토큰 검증 강화
```java
public boolean validateToken(String token) {
    try {
        Jwts.parserBuilder()
            .setSigningKey(key)
            .requireIssuer(ISSUER)  // 발급자 검증
            .build()
            .parseClaimsJws(token);
        return true;
    } catch (JwtException | IllegalArgumentException e) {
        log.warn("Invalid JWT token: {}", e.getMessage());
        return false;
    }
}
```

### 권한 검증 패턴

#### 리소스별 소유권 확인
```java
@PreAuthorize("@auctionService.isOwner(#auctionId, authentication.name)")
public void updateAuction(Long auctionId, UpdateAuctionRequest request) {
    // 본인 경매만 수정 가능
}

@PreAuthorize("@bidService.canViewBidHistory(#auctionId, authentication.name)")
public List<BidResponse> getBidHistory(Long auctionId) {
    // 관련 당사자만 입찰 내역 조회 가능
}
```

## ✅ 입력 검증 규칙

### 1. 다층 검증 체계

#### Bean Validation (1차)
```java
public class PlaceBidRequest {
    @NotNull(message = "경매 ID는 필수입니다")
    @Positive(message = "경매 ID는 양수여야 합니다")
    private Long auctionId;
    
    @NotNull(message = "입찰 금액은 필수입니다")
    @DecimalMin(value = "1000", message = "최소 입찰 금액은 1,000원입니다")
    private BigDecimal bidAmount;
}
```

#### 비즈니스 검증 (2차)
```java
private void validateBidAmount(Auction auction, BigDecimal bidAmount) {
    BigDecimal minimumBid = auction.getCurrentPrice().add(BigDecimal.valueOf(1000));
    
    if (bidAmount.compareTo(minimumBid) < 0) {
        throw new BusinessException(ErrorCode.INVALID_BID_AMOUNT);
    }
}
```

### 2. SQL Injection 방지

#### JPA Query 사용
```java
// ✅ 안전: 파라미터 바인딩
@Query("SELECT a FROM Auction a WHERE a.seller.id = :sellerId AND a.status = :status")
List<Auction> findBySellerAndStatus(@Param("sellerId") Long sellerId, 
                                   @Param("status") AuctionStatus status);

// ❌ 위험: 문자열 조합
// "SELECT * FROM auctions WHERE seller_id = " + sellerId  // SQL Injection 위험
```

## 📱 보안 모니터링

### 1. 보안 이벤트 추적

#### 실시간 모니터링 대상
```java
// 인증 실패 추적
@EventListener
public void handleAuthenticationFailure(AuthenticationFailureEvent event) {
    String ipAddress = getCurrentRequest().getRemoteAddr();
    String username = event.getAuthentication().getName();
    
    log.warn("Authentication failed: user={}, ip={}, reason={}", 
             username, ipAddress, event.getException().getMessage());
    
    // 실패 횟수 증가 및 임계치 체크
    securityEventService.recordFailedAttempt(ipAddress, username);
}

// 권한 위반 추적
@EventListener
public void handleAccessDenied(AccessDeniedEvent event) {
    log.error("Access denied: user={}, resource={}, ip={}", 
              event.getAuthentication().getName(),
              event.getSource(),
              getCurrentRequest().getRemoteAddr());
}
```

#### 보안 메트릭 수집
```java
@Component
public class SecurityMetrics {
    
    private final MeterRegistry meterRegistry;
    private final Counter authFailureCounter;
    private final Counter accessDeniedCounter;
    
    public SecurityMetrics(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        this.authFailureCounter = Counter.builder("security.auth.failures")
            .description("Authentication failure count")
            .register(meterRegistry);
        this.accessDeniedCounter = Counter.builder("security.access.denied")
            .description("Access denied count")
            .register(meterRegistry);
    }
    
    public void recordAuthFailure(String reason) {
        authFailureCounter.increment(Tags.of("reason", reason));
    }
    
    public void recordAccessDenied(String resource) {
        accessDeniedCounter.increment(Tags.of("resource", resource));
    }
}
```

### 2. 알림 및 대응

#### 자동 알림 규칙
- 1분간 인증 실패 10회 이상 → Slack 알림
- 동일 IP에서 5분간 접근 거부 5회 이상 → 관리자 알림
- SQL Injection 패턴 탐지 → 즉시 알림 + IP 차단

#### 대응 절차
1. **즉시 대응** (Critical): 시스템 중단, 관리자 개입
2. **긴급 대응** (High): 1시간 내 조치
3. **일반 대응** (Medium): 24시간 내 조치
4. **모니터링** (Low): 주간 리뷰

## 🎯 체크리스트

### 개발 시 확인사항

#### 예외 처리
- [ ] BusinessException 사용하여 민감 정보 노출 방지
- [ ] 스택 트레이스가 사용자에게 노출되지 않음
- [ ] 오류 메시지가 사용자 친화적임

#### 로깅
- [ ] 민감한 정보 로깅 금지 확인
- [ ] 적절한 로그 레벨 사용
- [ ] 보안 이벤트 적절히 기록

#### 데이터 보호
- [ ] 민감 데이터 암호화 적용
- [ ] 접근 권한 검증 구현
- [ ] 최소 권한 원칙 준수

#### 입력 검증
- [ ] Bean Validation 적용
- [ ] 비즈니스 규칙 검증
- [ ] SQL Injection 방지

### 배포 전 확인사항

#### 보안 설정
- [ ] DEBUG 로그 레벨 비활성화
- [ ] 프로덕션 환경 변수 설정
- [ ] CORS 정책 적절히 설정
- [ ] HTTPS 강제 적용

#### 모니터링
- [ ] 보안 메트릭 수집 활성화
- [ ] 알림 규칙 설정 완료
- [ ] 로그 수집 및 분석 도구 연동

---

## ⚠️ 보안 사고 대응

### 긴급 연락처
- **개발팀 리더**: [연락처]
- **인프라 담당자**: [연락처]
- **보안 담당자**: [연락처]

### 사고 대응 절차
1. **즉시 보고**: 보안 사고 발견 시 즉시 팀 리더에게 보고
2. **영향 범위 파악**: 데이터 유출 범위 및 피해 정도 확인
3. **즉시 조치**: 추가 피해 방지를 위한 긴급 조치
4. **복구 작업**: 시스템 복구 및 보안 강화
5. **사후 분석**: 원인 분석 및 재발 방지 대책 수립

---

> 📝 **참고**: 이 문서는 CherryPick 프로젝트의 보안 정책을 정의합니다. 
> 모든 개발자는 이 가이드라인을 숙지하고 준수해야 합니다.
> 
> **최종 업데이트**: 2025년 보안 강화 작업 완료 시점